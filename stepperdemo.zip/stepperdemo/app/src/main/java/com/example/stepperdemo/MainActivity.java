package com.example.stepperdemo;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private StepperPagerAdapter pagerAdapter;
    private Button btnNext, btnPrevious;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager = findViewById(R.id.view_pager);
        btnNext = findViewById(R.id.btn_next);
        btnPrevious = findViewById(R.id.btn_previous);

        pagerAdapter = new StepperPagerAdapter(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        viewPager.setAdapter(pagerAdapter);

        viewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                updateButtons(position);
            }
        });

        btnNext.setOnClickListener(v -> {
            int currentItem = viewPager.getCurrentItem();
            if (validateCurrentStep(currentItem)) {
                if (currentItem < 3) {
                    viewPager.setCurrentItem(currentItem + 1, true);
                } else {
                    Toast.makeText(MainActivity.this, "Finished!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MainActivity.this, "Please make sure all steps are filled correctly.", Toast.LENGTH_SHORT).show();
            }
        });

        btnPrevious.setOnClickListener(v -> {
            int currentItem = viewPager.getCurrentItem();
            if (currentItem > 0) {
                viewPager.setCurrentItem(currentItem - 1, true);
            }
        });

        // Initialize buttons state
        updateButtons(viewPager.getCurrentItem());
    }

    public void updateButtons(int position) {
        btnPrevious.setVisibility(position > 0 ? View.VISIBLE : View.GONE);
        btnNext.setText(position == 3 ? "Finish" : "Next");

        // Update button color and state based on validation
        boolean isValid = validateCurrentStep(position);
        btnNext.setEnabled(isValid);
        btnNext.setBackgroundColor(isValid ? Color.GREEN : Color.GRAY);
    }

    private boolean validateCurrentStep(int position) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag("android:switcher:" + R.id.view_pager + ":" + position);

        if (fragment instanceof Step1Fragment) {
            Step1Fragment step1 = (Step1Fragment) fragment;
            return step1.isAnyChannelSelected();
        } else if (fragment instanceof Step2Fragment) {
            Step2Fragment step2 = (Step2Fragment) fragment;
            return step2.isAnyPreferenceSelected();
        } else if (fragment instanceof Step3Fragment) {
            Step3Fragment step3 = (Step3Fragment) fragment;
            return step3.isPlanSelected();
        }

        return false;
    }
}
