package com.example.stepperdemo;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private StepperPagerAdapter pagerAdapter;
    private Button btnNext, btnPrevious;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager = findViewById(R.id.view_pager);
        btnNext = findViewById(R.id.btn_next);
        btnPrevious = findViewById(R.id.btn_previous);

        pagerAdapter = new StepperPagerAdapter(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        viewPager.setAdapter(pagerAdapter);

        viewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                updateButtons(position);
            }
        });

        btnNext.setOnClickListener(v -> {
            int currentItem = viewPager.getCurrentItem();
            if (validateCurrentStep(currentItem)) {
                if (currentItem < 3) {
                    viewPager.setCurrentItem(currentItem + 1, true);
                } else {
                    // Collect and display data on the final step
                    Step4Fragment step4Fragment = (Step4Fragment) pagerAdapter.instantiateItem(viewPager, 3);
                    Bundle args = new Bundle();
                    args.putString("channels", pagerAdapter.getChannels());
                    args.putString("preferences", pagerAdapter.getPreferences());
                    args.putString("plan", pagerAdapter.getPlan());
                    step4Fragment.setArguments(args);
                    Toast.makeText(MainActivity.this, "Finished! Check the final step.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnPrevious.setOnClickListener(v -> {
            int currentItem = viewPager.getCurrentItem();
            if (currentItem > 0) {
                viewPager.setCurrentItem(currentItem - 1, true);
            }
        });

        // Initialize buttons state
        updateButtons(viewPager.getCurrentItem());
    }

    public void updateButtons(int position) {
        btnPrevious.setVisibility(position > 0 ? View.VISIBLE : View.GONE);
        btnNext.setText(position == 3 ? "Finish" : "Next");

        // Update button color and state based on validation
        boolean isValid = validateCurrentStep(position);
        btnNext.setEnabled(isValid);
        btnNext.setBackgroundColor(isValid ? Color.GREEN : Color.GRAY);
    }

    private boolean validateCurrentStep(int position) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag("android:switcher:" + R.id.view_pager + ":" + position);

        if (fragment instanceof Step1Fragment) {
            Step1Fragment step1 = (Step1Fragment) fragment;
            if (!step1.isAnyChannelSelected()) {
                showError("Please select at least one channel.");
                return false;
            }
            pagerAdapter.setChannels(step1.getSelectedChannels());
        } else if (fragment instanceof Step2Fragment) {
            Step2Fragment step2 = (Step2Fragment) fragment;
            if (!step2.isAnyPreferenceSelected()) {
                showError("Please select at least one preference.");
                return false;
            }
            pagerAdapter.setPreferences(step2.getSelectedPreferences());
        } else if (fragment instanceof Step3Fragment) {
            Step3Fragment step3 = (Step3Fragment) fragment;
            if (!step3.isPlanSelected()) {
                showError("Please select a plan.");
                return false;
            }
            pagerAdapter.setPlan(step3.getSelectedPlan());
        }

        return true;
    }

    private void showError(String message) {
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}
