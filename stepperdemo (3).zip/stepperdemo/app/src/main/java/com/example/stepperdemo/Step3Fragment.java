package com.example.stepperdemo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Step3Fragment extends Fragment {

    private RadioGroup radioGroupPlans;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_step3, container, false);

        radioGroupPlans = view.findViewById(R.id.radio_group_plans);

        // रेडियो बटन के चयन पर बटन को अपडेट करें
        radioGroupPlans.setOnCheckedChangeListener((group, checkedId) -> {
            MainActivity activity = (MainActivity) getActivity();
            if (activity != null) {
                activity.updateButtons(2); // 2 से तात्पर्य है कि यह Step3Fragment है
            }
        });

        return view;
    }

    public boolean isPlanSelected() {
        // यह जांचता है कि कोई योजना चयनित है या नहीं
        return radioGroupPlans.getCheckedRadioButtonId() != -1;
    }

    public String getSelectedPlan() {
        // चयनित योजना का नाम प्राप्त करता है
        int selectedId = radioGroupPlans.getCheckedRadioButtonId();
        if (selectedId != -1) {
            RadioButton selectedRadioButton = getView().findViewById(selectedId);
            return selectedRadioButton.getText().toString();
        }
        return ""; // कोई योजना चयनित नहीं है
    }
}
